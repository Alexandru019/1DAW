<?php
    $server="localhost";
    $user="Alex";
    $pass="Tostus33,";
    $bd="Final3";
?>

